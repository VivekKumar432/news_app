import 'package:flutter/material.dart';
import 'package:newsappnew/screens/homepage.dart';

void main() {
  runApp(const MaterialApp(
    home: MyHomepage(),
    debugShowCheckedModeBanner: false,
  ));
}
